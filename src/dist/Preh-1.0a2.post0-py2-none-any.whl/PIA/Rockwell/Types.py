from enum import Enum

class CommonType:
    BOOL = "BOOL"
    SINT = "SINT"
    INT  = "INT"
    DINT = "DINT"
    REAL = "REAL"
    STRING = "STRING"
    COUNTER = "COUNTER"
    TIMER = "TIMER"
