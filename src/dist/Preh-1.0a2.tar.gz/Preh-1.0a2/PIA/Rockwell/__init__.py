__all__ = ["XML", "Types"]

from Types import CommonType
